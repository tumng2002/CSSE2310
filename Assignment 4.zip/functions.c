#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <csse2310a4.h>
#include <ctype.h>
#include <limits.h>
#include "functions.h"

/*
 * Parses the given parameter fileInput for a given ArgumentType type: LOWER,
 * UPPER, SEGMENTS and THREADS.
 * If the fileInput parameter is valid for type, parsed value of fileInput is 
 * saved at struct pointed by parameters and returns true.
 * If fileInput is invalid, returns false.
 *
 */
bool parse_arguments(JobfileInformation* parameters, char* fileInput, 
        ArgumentType type) {
    double boundValue;
    int segmentsOrThreads;
    int lengthWanted;
    
    if (type == LOWER || type == UPPER) {
        if (!sscanf(fileInput, "%lf%n", &boundValue, &lengthWanted)) {
            return false;
        }
    } else if (type == SEGMENTS || type == THREADS) {
        if (!sscanf(fileInput, "%d%n", &segmentsOrThreads, &lengthWanted)) {
            return false;
        }
        char* remainingString;
        long checkedInput = strtol(fileInput, &remainingString, 0);
        if (checkedInput > INT_MAX) {
            return false;
        } else if (checkedInput < INT_MIN) {
            segmentsOrThreads = INT_MIN; // any negative is invalid
        }
    }
    if (strlen(fileInput) > lengthWanted && type != THREADS) {
        return false; // deals with both unwanted chars and extra whitespace
    } else if (strlen(fileInput) - 1 > lengthWanted && type == THREADS) {
        return false; // includes the new line terminator
    }
    switch (type) {
        case LOWER:
            parameters->lowerLimit = boundValue;
            break;
        case UPPER:
            parameters->upperLimit = boundValue;
            break;
        case SEGMENTS:
            parameters->numberOfSegments = segmentsOrThreads;
            break;
        case THREADS:
            parameters->numberOfThreads = segmentsOrThreads;
            break;
    }
    return true;
}

/*
 * Prints syntax error message specifying the line it occurs on.
 */
void syntax_error(int lineNumber) {
    fprintf(stderr, "intclient: syntax error on line %d\n", lineNumber);
}  

/*
 * Returns a JobfileInformation struct with variables filled by information 
 * provided in fileLine. Argument lineNumber given, for syntax_error().
 * If lineNumber = 0, specifies that server is calling the function, otherwise
 * the function is being called on the client end.
 */
JobfileInformation get_file_information(char* fileLine, int lineNumber) {
    int checkingIndex, functionIndex, position = 0;
    char lineSplitter;
    char* fileInput;

    if (lineNumber == 0) {
        checkingIndex = 1;
        functionIndex = 5;
        lineSplitter = ADDRESS_SPLITTER;
    } else {
        checkingIndex = 0;
        functionIndex = 0;
        lineSplitter = JOBFILE_SPLITTER;
    }
    char** jobfileParts = split_by_char(fileLine, lineSplitter, 
            NUM_FIELDS_IN_JOB);

    JobfileInformation parameters;
    parameters.syntaxError = false;
    while ((fileInput = jobfileParts[position])) {
        if (!strcmp(fileInput, EMPTY_FIELD)) {
            if (lineNumber != 0) {
                syntax_error(lineNumber);
            }
            parameters.syntaxError = true;
            break;
        }
        if (checkingIndex == functionIndex) {
            parameters.function = fileInput;
            checkingIndex++;
            position++;
            continue;
        }
        if (argument_check(checkingIndex, fileInput, &parameters, 
                lineNumber)) {
            break;
        }
        position++;
        checkingIndex++;   
    }
    return parameters;
}

/*
 * Checks whether a fileInput at the given checkingIndex is a valid argument
 * that can be added to struct pointed at by parameters. checkingIndex can be:
 * LOWER_INDEX, UPPER_INDEX, SEGMENT_INDEX and THREAD_INDEX. If given 
 * fileInput is valid from parse_arguments, returns true, else inn the case 
 * of syntax error and lineNumber is not 0 (client call), calls syntax_error()
 * and returns false.
 * 
 */
bool argument_check(int checkingIndex, char* fileInput,
        JobfileInformation* parameters, int lineNumber) {        
    ArgumentType type;
    bool forceExit;
    switch (checkingIndex) {
        case LOWER_INDEX:
            type = LOWER;
            if (!parse_arguments(parameters, fileInput, type)) {
                forceExit = true;
            }
            break;
        case UPPER_INDEX:
            type = UPPER;
            if (!parse_arguments(parameters, fileInput, type)) {
                forceExit = true;
            }
            break;
        case SEGMENT_INDEX:
            type = SEGMENTS;
            if (!parse_arguments(parameters, fileInput, type)) {
                forceExit = true;
            }
            break;
        case THREAD_INDEX:
            type = THREADS;
            if (!parse_arguments(parameters, fileInput, type)) {
                forceExit = true;
            }
            break;
    }
    if (forceExit) {
        if (lineNumber != 0) {
            syntax_error(lineNumber);
        }
        parameters->syntaxError = true;
    }
    return forceExit;
}

/*
 * Checks through the validity of the integration job's parameters given in 
 * parameters. If valid, returns true, else if lineNumber is not 0 and 
 * a given parameter in parameters struct is invalid, returns false with 
 * error message indicating point of occurrence using lineNumber.
 */
bool check_file_information(JobfileInformation parameters, int lineNumber) {
    for (int characterIndex = 0; characterIndex < strlen(parameters.function);
            characterIndex++) {
        if (isspace(parameters.function[characterIndex])) {
            if (lineNumber != 0) {
                fprintf(stderr, "intclient: spaces not permitted in expression"
                        " (line %d)\n", lineNumber);
            }
            return false;
        }
    }

    if (parameters.upperLimit <= parameters.lowerLimit) {
        if (lineNumber != 0) {
            fprintf(stderr, "intclient: upper bound must be greater than lower"
                    " bound (line %d)\n", lineNumber);
        }
        return false;
    } else if (parameters.numberOfSegments < 1) {
        if (lineNumber != 0) {
            fprintf(stderr, "intclient: segments must be a positive integer"
                    " (line %d)\n", lineNumber);
        }
        return false;
    } else if (parameters.numberOfThreads < 1) {
        if (lineNumber != 0) {
            fprintf(stderr, "intclient: threads must be a positive integer"
                    " (line %d)\n", lineNumber);
        }
        return false;
    } else if ((parameters.numberOfSegments % parameters.numberOfThreads)) {
        if (lineNumber != 0) {
            fprintf(stderr, "intclient: segments must be an integer multiple "
                    "of threads (line %d)\n", lineNumber);
        }
        return false;
    }
    return true;
}

/*
 * Reads from socket and allocates memory and values to status, method, 
 * statusExaplanationOrAddress, headers and body. ParsingEnd describes where
 * the call comes from and can be either CLIENT or SERVER. In the case of
 * server, status can be NULL and for a client, method can be NULL. Function
 * returns the response status given by either parse_HTTP_request for server
 * or parse_HTTP_response for a client.
 */
int get_response_request(int socket, int* status, char** method,
        char** statusExplanationOrAddress, HttpHeader*** headers, char** body,
        ParsingEnd type) {
    char* response = malloc(STRING_SIZE);
    // defaults to 0 since starts with not enough. Will be overwritten.
    int responseStatus = 0;
    bool needsMore = false;
    char* isExtra = malloc(STRING_SIZE);

    while (recv(socket, isExtra, STRING_SIZE - 1, 0) > 0) {
        if (!needsMore) {
            strcpy(response, isExtra);
        } else {
            response = realloc(response,
                    strlen(response) + strlen(isExtra) + 2);
            strcat(response, isExtra);
        }
        needsMore = false;
        free(isExtra);
        if (type == CLIENT) {
            responseStatus = parse_HTTP_response(response, strlen(response), 
                    status, statusExplanationOrAddress, headers, body);
        } else if (type == SERVER) {
            responseStatus = parse_HTTP_request(response, strlen(response), 
                    method, statusExplanationOrAddress, headers, body);
        }
        if (responseStatus == 0) {
            needsMore = true;
            isExtra = malloc(STRING_SIZE);
            continue; //block until more is received.

        } else if (responseStatus == -1 || !needsMore) {
            break;
        }
    }
    return responseStatus;
}



