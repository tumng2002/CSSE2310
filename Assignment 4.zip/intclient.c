#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/socket.h>
#include <unistd.h>
#include <csse2310a4.h>
#include <ctype.h>
#include <sys/types.h>
#include <csse2310a3.h>
#include "functions.h"
#include "intclient.h"

/*
 * Prints usage error message and exits with status 1.
 */
void usage_error(void) {
    fprintf(stderr, "Usage: intclient [-v] portnum [jobfile]\n");
    exit(1);
}

/*
 * Checks if commandLineInput is "-v", returns true in this case, else returns
 * false.
 */
bool check_verbose(char* commandLineInput) {
    if (!strcmp("-v", commandLineInput)) {
            return true;
    }
    return false;
}

/*
 * Checks input and allocates input to serviceName or jobfile if serviceName 
 * already allocated. If jobfile unopenable, exits with status 4 and prints 
 * error message. 
 */
void check_command_line(int* jobfile, char** serviceName, char* input) {
    if (!strcmp(*serviceName, EMPTY_FIELD)) {
        *serviceName = input;
    } else if (strcmp(*serviceName, EMPTY_FIELD) && !(*jobfile)) {
        *jobfile = open(input, O_RDONLY);
        if ((*jobfile) == -1) {
            fprintf(stderr, "intclient: unable to open \"%s\" for reading\n", 
                    input);
            exit(4);
        }
    }
}

/*
 * Prints socket connecting error message and exits with status 2.
 */
void socket_connect_fail(char* serviceName, struct addrinfo* addressInfo) {
    freeaddrinfo(addressInfo);
    fprintf(stderr, "intclient: unable to connect to port %s\n",
            serviceName);
    exit(2);
}

/*
 * Attempt to connect to server on port serviceName on localhost. Returns 
 * socketDescriptor if connection succeeds.
 */
int connect_to_server(char* serviceName) {
    struct addrinfo* addressInfo = NULL;
    struct addrinfo hints;
    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    int errorConnect;
    if ((errorConnect = getaddrinfo("localhost", serviceName, &hints,
            &addressInfo))) {
        socket_connect_fail(serviceName, addressInfo);
    }

    int socketDescriptor = socket(AF_INET, SOCK_STREAM, 0);
    if (connect(socketDescriptor, (struct sockaddr*)addressInfo->ai_addr, 
            sizeof(struct sockaddr))) {
        socket_connect_fail(serviceName, addressInfo);
    }

    return socketDescriptor;
}

/*
 * Prints the integration results using results stored in body and job 
 * constraints given in parameters. If verbose true, also prints the partial 
 * results of individual computation threads.
 */
void print_result(char* body, JobfileInformation parameters, bool verbose) {
    char* result;
    // split the body by \n and +2 to separate the last line w/ integration
    // result & its \n char
    char** splitBody = split_by_char(body, PARTIAL_RESULT_SPLITTER, 
            parameters.numberOfThreads + 2);

    if (verbose) {
        for (int threadNumber = 0; 
                threadNumber < parameters.numberOfThreads;
                threadNumber++) {
            fprintf(stdout, "%s\n", splitBody[threadNumber]);
        }
        result = splitBody[parameters.numberOfThreads];
    } else {
        result = body;
    }
    fprintf(stdout, "The integral of %s from %lf to %lf is %s\n", 
            parameters.function, parameters.lowerLimit, 
            parameters.upperLimit, result);
    free(splitBody);
}

/*
 * Prints communication error message and exits with status 3.
 */
void communication_error(void) {
    fprintf(stderr, "intclient: communications error\n");
    exit(3);
}

/*
 * Sends request specified by type to server through socket descriptor. 
 * Parameters argument provides the required information for the request. 
 * If verbose, header for verbose added to integration request. Function 
 * returns true if integration job was successful, else invalid request 
 * handled. 
 */
bool send_requests(JobfileInformation parameters, int lineNumber, int socket, 
        RequestType type, bool verbose) {
    char request[MESSAGE_BUFFER];

    if (type == VALIDATE) {
        sprintf(request, "GET /validate/%s HTTP/1.1\r\n\r\n",
                parameters.function);
                
    } else if (type == INTEGRATE) {
        sprintf(request, "GET /integrate/%lf/%lf/%d/%d/%s HTTP/1.1\r\n",
                parameters.lowerLimit, parameters.upperLimit,
                parameters.numberOfSegments, parameters.numberOfThreads, 
                parameters.function);
        if (verbose) {
            strcat(request, "X-Verbose: yes\r\n");
        }
        strcat(request, "\r\n");
    }
    if (send(socket, request, strlen(request), 0) == -1) {
        communication_error();
    }

    ParsingEnd parsingType = CLIENT;
    int status;
    HttpHeader** headers;
    char* statusExplanation;
    char* body;
    int responseStatus = get_response_request(socket, &status, NULL, 
            &statusExplanation, &headers, &body, parsingType);
    
    if (responseStatus < 1 || (status != 200 && status != 400)) {
        // if response still incomplete or bad response
        communication_error();
    }
    if (status == 400 && type == VALIDATE) {
        fprintf(stderr, "intclient: bad expression \"%s\" (line %d)\n",
                parameters.function, lineNumber);
        return false;
    } else if (status == 400 && type == INTEGRATE) {
        fprintf(stderr, "intclient: integration failed\n");
    } else if (type == INTEGRATE) {
        print_result(body, parameters, verbose);
    } 
    return true;
}

/*
 * Checks if given readLine is empty. Returns true if field is empty, false
 * otherwise.
 */
bool check_empty_field(char* readLine) {
    for (int index = 0; index < strlen(readLine); index++) {
        char checkedForSpace = readLine[index];
        if (!isspace(checkedForSpace)) {
            return false;
        }
    }
    return true;
}

/*
 * Reads from givenJobfile and allocates parameters of integration job. Calls
 * send_requests() to send validate and integrate requests to server using 
 * socket. Argument verbose used in send_requests().
 */
void parse_jobfiles(FILE* givenJobfile, int socket, bool verbose) {
    char* readLine = malloc(STRING_SIZE);
    int lineNumber = 0;
    while ((readLine = fgets(readLine, MESSAGE_BUFFER, givenJobfile))) {
        lineNumber++;

        JobfileInformation parameters;
        if (readLine[0] == ('#') || check_empty_field(readLine)) {
            continue;
        }
        parameters = get_file_information(readLine, lineNumber);
        RequestType request = VALIDATE;
        if (parameters.syntaxError || 
                !check_file_information(parameters, lineNumber) ||
                !send_requests(parameters, lineNumber, socket, request, 
                verbose)) {
            continue;
        }
        request = INTEGRATE;
        send_requests(parameters, lineNumber, socket, request, verbose);
    }
}

int main(int argc, char* argv[]) {
    bool verbose = false;
    int jobfileDescriptor = 0;
    char* serviceName = "";
    FILE* givenJobfile;

    if (argc > 4) {
        usage_error();
    }
    for (int commandLineIndex = 1; commandLineIndex < argc;
            commandLineIndex++) {
        if (commandLineIndex == VERBOSE_INDEX) {
            verbose = check_verbose(argv[commandLineIndex]);  
            if (verbose) {
                continue;
            } else if (argc > 3) {
                //if verbose not present, only should have 3 args max.
                usage_error();
            }
        }
        check_command_line(&jobfileDescriptor, &serviceName, 
                argv[commandLineIndex]);
    }
    if (!strcmp(serviceName, EMPTY_FIELD)) {
        usage_error();
    }
    
    if (jobfileDescriptor) {
        givenJobfile = fdopen(jobfileDescriptor, "r");
    } else {
        givenJobfile = fdopen(STDIN_FILENO, "r");
    }
    int socket = connect_to_server(serviceName);
    parse_jobfiles(givenJobfile, socket, verbose);
    return 0;

}
        



