#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

// Libraries
#include <stdbool.h>
#include <csse2310a4.h>

// Macros
#define MESSAGE_BUFFER 200
#define LOWER_INDEX 1
#define UPPER_INDEX 2
#define CHECKED_INDEX 2
#define SEGMENT_INDEX 3
#define THREAD_INDEX 4
#define NUM_FIELDS_IN_JOB 5
#define EMPTY_FIELD ""
#define STRING_SIZE MESSAGE_BUFFER * sizeof(char)
#define ADDRESS_SPLITTER '/'
#define JOBFILE_SPLITTER ','

// Data Structures
/* Type of argument for an integration job.  */
typedef enum {
    LOWER, UPPER, SEGMENTS, THREADS
} ArgumentType;

/* Type of request. */
typedef enum {
    VALIDATE, INTEGRATE
} RequestType;

/* Type of user. */
typedef enum {
    CLIENT, SERVER
} ParsingEnd;

/* Information required for given job. */
typedef struct {
    char* function;
    double lowerLimit;
    double upperLimit;
    int numberOfSegments;
    int numberOfThreads;
    bool syntaxError;
} JobfileInformation;

// Function Definitions
bool parse_arguments(JobfileInformation* parameters, char* fileInput, 
        ArgumentType type);
JobfileInformation get_file_information(char* fileLine, int lineNumber); 
bool check_file_information(JobfileInformation parameters, int lineNumber); 
int get_response_request(int socket, int* status, char** method,
        char** statusExplanationOrAddress, HttpHeader*** headers, char** body,
        ParsingEnd type);
void syntax_error(int lineNumber);
bool argument_check(int checkingIndex, char* fileInput,
        JobfileInformation* parameters, int lineNumber);
#endif

