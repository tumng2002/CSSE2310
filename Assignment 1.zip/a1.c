#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define LENGTH "-len"
#define ALPHA "-alpha"
#define LONG "-longest"
#define INC "-include"
#define NORM "normal"


/*
 * Filters the inputs given by the user, allocating the letters to sort from,
 * and if specified, the sorting style, the char to include in the search and 
 * the dictionary to search from.
 * Returns 0 if successful, 1 if there was an error in the given arguments.
 */
int filter_input(int argc, char** argv, char** sortingType, char* searchingFor,
        char** dictionaryName, char** letters) {
    int sorting = 0;
    int include = 0;

    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '-' && (*letters) == NULL) {
            if (!strcmp(argv[i], ALPHA)) {
                sorting++;
                *sortingType = ALPHA;
            } else if (!strcmp(argv[i], LENGTH)) {
                sorting++;
                *sortingType = LENGTH;
            } else if (!strcmp(argv[i], LONG)) {
                sorting++;
                *sortingType = LONG;
            } else if (!strcmp(argv[i], INC)) {
                include++;
                i++;
                if (i != argc && strlen(argv[i]) == 1 &&
                        isalpha(argv[i][0])) {
                    *searchingFor = argv[i][0];
                } else {
                    return 1; //not single letter char
                }
            } else {
                return 1; //invalid sorting arg
            }
        } else if ((*letters) == NULL) {
            *letters = argv[i];
        } else if ((*dictionaryName) == NULL) { //returns 0 when true
            *dictionaryName = argv[i];
        } else if ((*dictionaryName) != NULL) {
            return 1; // if there are more arguments and dictionary defined,
                      // too many args.
        }
    }

    if (*dictionaryName == NULL) {
        *dictionaryName = "/usr/share/dict/words"; //defaults to words
    }
    if (sorting > 1 || include > 1) {
        return 1;
    }
    if ((*letters) == NULL) {
        return 1;
    } else if (strlen(*letters) < 3) {
        return 3;
    }
    return 0;
}

/*
 * Reads and returns a line of a dictionary.
 * If the dictionary is at the end of the file, return "EOF".
 */
char* read_line(FILE* dictionary, char* word) {
    char c; 
    int i = 0;

    while ((c = fgetc(dictionary)) != '\n') {
        if (c == EOF) {
            free(word);
            return "(1)"; //terminating character 
        }
        word[i] = c;
        i++;
    } 
    word[i] = '\0';

    return word;
}

/*
 * Comparator function which sorts words in lexicographical order.
 * Returns -1 if the first word is before the second word, 1 if the first word
 * is after the second word and 0 if they are the same.
 */
int alpha_sort(const void* word1, const void* word2) {
    char* firstWord = *(char**)word1;
    char* secondWord = *(char**)word2;
    if (strlen(firstWord) == strlen(secondWord)) {
        int comp = strcasecmp(firstWord, secondWord);
        if (comp == 0) {
            return strcmp(firstWord, secondWord);
        } else if (comp < 0) {
            return -1;
        } else {
            return 1;
        }

    } else {
        int comp = strcasecmp(firstWord, secondWord);
        if (comp < 0) {
            return -1;
        } else {
            return 1;
        }
    }
    return 0;
}

/*
 * Checks whether given letters are valid (only uppercase and lower case 
 * alphabeticl characters).
 * Returns 0 if all chars are valid, else returns 1.
 */
int verify_letters(char** letters) {

    for (int i = 0; i < strlen(*letters); i++) {
        if ((isalpha((*letters)[i])) == 0) {
            return 1;
        }
    }
    return 0;
}

/*
 * Removes a character from a string from the pointer value p. 
 */
void remove_char(char* copy, char* backup, char* p) {
    int j = 0;
    for (int i = 0; i < strlen(copy); i++) {
        if (i != (strlen(copy) - strlen(p))) {
            backup[j] = copy[i];
            j++;
        }
    }
    backup[j] = '\0';
    strcpy(copy, backup);
}

/*
 * Checks whether the given word can be made from the letters given by user.
 * Returns 1 if the word cannot be formed, else returns 0.
 */
int checking_match(char* letters, char* copyLetters,
        char* word, char* backupLetters) {

    strcpy(copyLetters, letters);

    for (int i = 0; i < strlen(word); i++) {
        char fromWordUpper = (char) toupper((int) word[i]);
        char fromWordLower = (char) tolower((int) word[i]);
        char* p = strchr(copyLetters, fromWordUpper);
        char* q = strchr(copyLetters, fromWordLower);
        if (p != NULL) {
            remove_char(copyLetters, backupLetters, p);
        } else if (q != NULL) {
            remove_char(copyLetters, backupLetters, q);
        }

    }

    if ((strlen(letters) - strlen(copyLetters)) != strlen(word)) {
        return 1;
    }
    return 0;
}

/*
 * Comparator used to sort words with longer words having precedence.
 * If words are of same length, sorts in order given by function alpha_sort.
 * Returns -1 if first word precedes, the second word, 1 if first word
 * proceeds the second word, and 0 if the words are the same.
 */
int length_sort(const void* word1, const void* word2) {
    char* firstWord = *(char**)word1;
    char* secondWord = *(char**)word2;
    if (strlen(firstWord) > strlen(secondWord)) {
        return -1;
    } else if (strlen(firstWord) < strlen(secondWord)) {
        return 1;
    } else {
        return alpha_sort(word1, word2);
    }
    return 0;
}

/*
 * Frees the 2D array of saved words.
 */
void free_saved_words(char** savedWords, int countOfMatches) {
    for (int i = 0; i <= countOfMatches; i++) {
        free(savedWords[i]);
    }
    free(savedWords);
}

/*
 * Advanced functionality that sorts the valid words with method specified by
 * user. Each word is then printed.
 * Sorting can either be lexicographically, by length, or by tthe longest 
 * available word(s).
 */
void advanced_sort(char* sortingType, char** savedWords, int countOfMatches) {
    if (!strcmp(sortingType, ALPHA)) {
        qsort(savedWords, countOfMatches, sizeof(char*), alpha_sort);
    } else if (!strcmp(sortingType, LENGTH) || !strcmp(sortingType, LONG)) {
        qsort(savedWords, countOfMatches, sizeof(char*), length_sort);
    }
    
    if (!strcmp(sortingType, LONG)) {
        int longestLength = strlen(savedWords[0]);
        int i = 0;
        char* longest = savedWords[i];
        do {
            printf("%s\n", longest);
            if (i + 1 == countOfMatches) {
                break;
            }
            i++;
            longest = savedWords[i];
        } while (strlen(longest) == longestLength);
    } else {
        for (int i = 0; i < countOfMatches; i++) {
            printf("%s\n", savedWords[i]);
        }
    }
}

/*
 * Sorts the words read from a dictionary. If the sortingType is not specified,
 * words which can be created from the given letters are printed in the order.
 * read from the dictionary. 
 * If a sortingType is specified, the advanced_sort function is called and this
 * function does not print.
 * Returns 1 if there were no words that can be created from the given letters,
 * else returns 0.
 */
int sort_words(char* letters, FILE* dictionary, char* sortingType, 
        char searchingFor) {
    char* word = malloc(sizeof(char) * 52); 
    char* backupLetters = malloc(sizeof(char) * strlen(letters) + 2);
    char* copyLetters = malloc(sizeof(char) * strlen(letters) + 2);
    char** savedWords = malloc(sizeof(char*));
    savedWords[0] = malloc(sizeof(char) * 52);

    int countOfMatches = 0;
    while (1) { 
        word = read_line(dictionary, word);
        if ((strcmp(word, "(1)")) == 0) {
            break; // since using "", not dynamic, no need to free
        } else if (strlen(letters) < strlen(word) ||
                checking_match(letters, copyLetters, word, backupLetters) ||
                strlen(word) < 3) {
            continue;
        } 
        if (searchingFor != '~') { 
            char upperSearch = (char) toupper((int) searchingFor);
            char lowerSearch = (char) tolower((int) searchingFor);
            if ((strchr(word, lowerSearch) == NULL && 
                    (strchr(word, upperSearch) == NULL)) && 
                    searchingFor) {
                continue;
            }
        }
        strcpy(savedWords[countOfMatches], word);
        if (!strcmp(sortingType, NORM)) {
            fprintf(stdout, "%s\n", word);
        }
        countOfMatches++;
        savedWords = realloc(savedWords,
                (countOfMatches + 1) * sizeof(char*) + sizeof(char*));
        savedWords[countOfMatches] = malloc(sizeof(char) * 52);

    } 
    if (countOfMatches == 0) {
        return 1;
    } else if (strcmp(sortingType, NORM)) {
        advanced_sort(sortingType, savedWords, countOfMatches);
    }
    free_saved_words(savedWords, countOfMatches);
    free(copyLetters);
    free(backupLetters);

    return 0;

}

int main(int argc, char** argv){
    char* sortingType = NORM; //style of sorting, normal default
    char searchingFor = '~'; //char to include in search, defaults to '~'
    char* dictionaryName = NULL; // name of dictionary to search in
    char* letters = NULL; //letters to filter through

    int filterResult = filter_input(argc, argv, &sortingType, &searchingFor,
            &dictionaryName, &letters);
    switch (filterResult) {
        case 1:
            fprintf(stderr, "Usage: unjumble [-alpha|-len|-longest]"
                    " [-include letter] letters [dictionary]\n");
            return 1;
        case 3:
            fprintf(stderr, "unjumble: must supply at least three letters\n");
            return 3;
    }

    FILE* dictionary = fopen(dictionaryName, "r");
    if (dictionary == NULL) {
        fprintf(stderr,
                "unjumble: file \"%s\" can not be opened\n", dictionaryName);
        return 2;
    }

    int verifyLetters = verify_letters(&letters);
    if (verifyLetters) {
        fprintf(stderr, "unjumble: can only unjumble alphabetic characters\n");
        return 4;
    }
    
    int sortResult = sort_words(letters, dictionary, sortingType,
            searchingFor);
    fclose(dictionary);;
    if (sortResult == 1) {
        return 10;
    }
  
    return 0;

}

