#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include <csse2310a3.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/types.h>

#define PIPE_SYMBOL '@'
#define PROGRAM_INDEX 0
#define PIPE_SYMBOL_INDEX 0
#define READ_END 0
#define WRITE_END 1
#define STANDARD_IN 0
#define STANDARD_OUT 1
#define VERBOSE_INDEX 1
#define SPEC_IN_INDEX 1
#define SPEC_OUT_INDEX 2
#define STANDARD_ERROR 2
#define PIPE_BUFFER 2
#define TIMEOUT_INDEX 3
#define EMPTY_FIELD ""
#define PARAMETER_SETUP {false, "", "", "",\
     malloc(2*sizeof(int)),"", 0, malloc(sizeof(char*)), 0}
#define JOBFILE_SETUP {malloc(sizeof(FILE*)), malloc(sizeof(char*)),\
     malloc(sizeof(JobfileParameters)), malloc(sizeof(JobfilePipeEnds)),\
     malloc(sizeof(JobfilePipeDescriptors)), 0, 0, 0, 0, false};
#define PIPE_SETUP {0, "", false, false}

/* Structure type to store information about a specific job. */
typedef struct {
    bool jobInvalid; 
    char* programName; 
    char* specIn; 
    char* specOut;
    int* specIO;
    char* timeout;
    int timeoutValue;
    char** givenArguments;
    int numberOfArguments;
} JobfileParameters;

/* Structure type that contains the information of a single pipe end. */
typedef struct {
    int pipeDirection;
    char* pipeName;
    bool validPipe;
    bool printed;
} JobfilePipeEnds;

/* 
 * Structure type that stores all the file descriptors for input and output
 * pipes.
 */
typedef struct {
    char* pipeName;
    int inputDescriptor;
    int outputDescriptor;
} JobfilePipeDescriptors;

/* 
 * Structure type that stores all the information required to setup 
 * the jobfiles given. 
 */
typedef struct {
    FILE** listOfJobfiles;
    char** jobfileNames;
    JobfileParameters* fileParameters;
    JobfilePipeEnds* filePipes;
    JobfilePipeDescriptors* fileDescriptors;
    int numberOfPipes;
    int numberOfJobfiles;
    int numberOfParameters;
    int numberOfPipeEnds;    
    bool verbose;
} Jobfiles;

/* Structure type containing information of a file run by a child process */
typedef struct {
    int jobfileNumber;
    int childPID;
    int timeoutValue;
    bool timeout;
} RunnableFileInfo;

/* Whether the child process has sent the jobrunner SIGHUP */
bool terminateChildren = false;

/* Function Declarations */

void sighup_received(int signal);
void usage_error(void);
void filter_input(Jobfiles* jobfiles, char* fileName);
void check_verbose(Jobfiles* jobfiles, char* commandLineInput, int pointer);
void sort_parameters(char* line, JobfileParameters* fileInfo);
bool check_parameters(JobfileParameters* parameters);
void parsing_error(int lineNumber, char* fileName);
void allocate_pipe_ends(Jobfiles* jobfiles, char* pipeName, int pipeEnd);
void allocate_input_output(JobfileParameters* fileInfo, int specIndex,
        Jobfiles* jobfiles);
void input_output_allocation(JobfileParameters* fileInfo, Jobfiles* jobfiles);
void parse_jobfiles(FILE* givenJobfile, char* jobfileName, Jobfiles* jobfiles);
void add_pipe_descriptors(JobfilePipeEnds* pipeEnd, Jobfiles* jobfiles);
void bad_pipe_pairs(JobfilePipeEnds* checkedPipe, JobfilePipeEnds* pipePair,
        char* checkedPipeName);
void check_pipe_validity(Jobfiles* jobfiles);
bool invalidate_pipe_end(char* pipeEndName, Jobfiles* jobfiles);
void jobs_cascading_invalidate(Jobfiles* jobfiles);
void pipes_cascading_invalidate(Jobfiles* jobfiles);
void update_invalid_jobs(Jobfiles* jobfiles);
void open_pipe_end(char* filePipe, Jobfiles* jobfiles, int pipeEnd);
void close_file_descriptors(Jobfiles* jobfiles);
void child_execute_job(JobfileParameters job, Jobfiles* jobfiles);
int check_on_children(RunnableFileInfo* runJobs, int numberOfJobsRemaining,
        int numberOfJobsRun, int timeElapsed);
void run_jobs(Jobfiles* jobfiles);
void print_verbose(Jobfiles* jobfiles);

/*****************************************************************************/

/*
 * Event handler that sets terminateChildren variable to true if triggered by
 * SIGHUP signal.
 */
void sighup_received(int signal) {
    terminateChildren = true;
}

/*
 * Prints usage error message, exits with exit status of 1.
 */
void usage_error(void) {
    fprintf(stderr, "Usage: jobrunner [-v] jobfile [jobfile ...]\n");
    exit(1);
}

/* 
 * Checks whether a given file in the command line can be opened. If cannot be
 * opened, exits with status 2 and prints error message. If the file can be 
 * opened, file is added to jobfiles listOfJobfiles, with the name of the file
 * also saved.
 */
void filter_input(Jobfiles* jobfiles, char* fileName) {
    FILE* givenJobfile = fopen(fileName, "r");
    if (!givenJobfile) {
        fprintf(stderr, "jobrunner: file \"%s\" can not be opened\n", 
                fileName);
        exit(2);
    }
    jobfiles->numberOfJobfiles++;
    jobfiles->listOfJobfiles = realloc(jobfiles->listOfJobfiles,
            sizeof(FILE*) * (jobfiles->numberOfJobfiles));
    jobfiles->jobfileNames = realloc(jobfiles->jobfileNames,
            sizeof(char*) * (jobfiles->numberOfJobfiles));
    jobfiles->listOfJobfiles[jobfiles->numberOfJobfiles - 1] = givenJobfile;
    jobfiles->jobfileNames[jobfiles->numberOfJobfiles - 1] = fileName;

}

/*
 * Checks if given commandLineInput is verbose term. If it is the verbose term
 * but the pointer does not correspond with the VERBOSE_INDEX, usage_error() 
 * function is called. Else if it is the verbose term and the pointer is at
 * the specified VERBOSE_INDEX, verbose variable of jobfiles argument is set
 * to true.
 */
void check_verbose(Jobfiles* jobfiles, char* commandLineInput, int pointer) {
    if (!strcmp("-v", commandLineInput)) {
        if (pointer != VERBOSE_INDEX) {
            usage_error();
        } else {
            jobfiles->verbose = true;
        }
    }
}

/*
 * Fills fileInfo with information about the programName, the specIn, the 
 * specOut, the timeout and the extra arguments from the given line.
 */
void sort_parameters(char* line, JobfileParameters* fileInfo) {
    char** separatedLine = split_by_commas(line);
    int jobParameterPosition = 0;
    char* parameterValue;
    while ((parameterValue = separatedLine[jobParameterPosition])) {
        switch (jobParameterPosition) {
            case SPEC_IN_INDEX:
                fileInfo->specIn = parameterValue;
                break;
            case SPEC_OUT_INDEX:
                fileInfo->specOut = parameterValue;
                break;
            case TIMEOUT_INDEX:
                fileInfo->timeout = parameterValue;
                break;
            case PROGRAM_INDEX:
                fileInfo->programName = parameterValue;
            default:
                if (strcmp(parameterValue, EMPTY_FIELD)) {
                    fileInfo->numberOfArguments++;
                    fileInfo->givenArguments = 
                            realloc(fileInfo->givenArguments,
                            fileInfo->numberOfArguments * sizeof(char*));
                    fileInfo->givenArguments[fileInfo->numberOfArguments - 1] =
                            parameterValue;
                }
        }
        jobParameterPosition++;
    }
    fileInfo->givenArguments[fileInfo->numberOfArguments]= NULL;
    free(separatedLine);
}

/*
 * Checks if the parameters of a given job has been correctly established.
 * Parameters must have a programName, a specIn and a specOut; if these are 
 * EMPTY_FIELDS, then function returns false. If a timeout is specified, it 
 * returns false if the timeout is less than 0 or the given timeout is not 
 * strictly digits (ie. contains alphabetical characters or whitespace). If 
 * the given parameters has a programName, a specIn, a specOut and a valid
 * timeout, function returns true.
 */
bool check_parameters(JobfileParameters* parameters) {
    if (!strcmp(parameters->specOut, EMPTY_FIELD) ||
            !strcmp(parameters->specIn, EMPTY_FIELD) ||
            !strcmp(parameters->programName, EMPTY_FIELD)) {
        return false;
    } else if (strcmp(parameters->timeout, EMPTY_FIELD)) {
        for (int characterIndex = 0; 
                characterIndex < strlen(parameters->timeout);
                characterIndex++) {
            int result = isdigit(parameters->timeout[characterIndex]);
            if (!result) {
                // for any instance the char is not a digit, it is invalid
                // timeout
                return false; 
                
            }
        }
        if (atoi(parameters->timeout) < 0) {
            return false;
        }
    }
    return true;
}

/*
 * Prints error message specifying the file affected by an invalid job and
 * which line in this file the invalid specification has occurred. Program
 * then exits with status 3.
 */
void parsing_error(int lineNumber, char* fileName) {
    fprintf(stderr, "jobrunner: invalid job specification on line %d of "
            "\"%s\"\n", lineNumber, fileName);
    exit(3);
}

/*
 * givePipe struct is populated with the PIPE_SETUP macro. The pipeName of the
 * givenPipe is changed alongside the pipeDirection using the given arguments
 * pipeName and pipeEnd respectively. givenPipe is then appended to jobfiles' 
 * filePipes array, which is dynamically allocated memory.
 */
void allocate_pipe_ends(Jobfiles* jobfiles, char* pipeName, int pipeEnd) {
    JobfilePipeEnds givenPipe = PIPE_SETUP;
    givenPipe.pipeDirection = pipeEnd;
    givenPipe.pipeName = pipeName;

    jobfiles->numberOfPipeEnds++;
    jobfiles->filePipes = realloc(jobfiles->filePipes,
            sizeof(JobfilePipeEnds) * jobfiles->numberOfPipeEnds);
    jobfiles->filePipes[jobfiles->numberOfPipeEnds - 1] = givenPipe;
}

/*
 * Allocates the input and output of fileInfo. If specIndex == SPEC_IN_INDEX,
 * specIO will be adjusted for reading, else, specIO is adjusted 
 * for writing. specIO can be STANDARD_IN or STANDARD_OUT if the given specIn 
 * or specOut is "-". If a fileInfo has specIn or specOut as pipes, then 
 * allocate_pipe_ends with jobfiles argument. Otherwise, specIn is opened with 
 * read only and specOut is opened with write only. If specOut file does not 
 * exist, then it is created. If it already exists, the file is then truncated
 * after the write. In the case that opening for reading or writing has failed,
 * an error message is printed specifiying what file could not be opened and  
 * the jobInvalid field of the fileInfo argument is set to true. 
 * If no issues arise and specIO is defined, the file descriptor is added to  
 * the specIO array in fileInfo corresponding to whether it is a read end or
 * a write end. 
 */
void allocate_input_output(JobfileParameters* fileInfo, int specIndex,
        Jobfiles* jobfiles) {
    int specIO;
    bool isPipe = false;
    int readOrWrite;

    if (specIndex == SPEC_IN_INDEX) {
        readOrWrite = READ_END;
        if (!strcmp(fileInfo->specIn, "-")) {
            specIO = STANDARD_IN;
        } else if (fileInfo->specIn[PIPE_SYMBOL_INDEX] == PIPE_SYMBOL) {
            allocate_pipe_ends(jobfiles, fileInfo->specIn, READ_END);
            isPipe = true;
            specIO = STANDARD_IN; //placeholder for pipe later on
        } else {
            specIO = open(fileInfo->specIn, O_RDONLY);
        }
        if (specIO == -1 && !isPipe)  {
            fprintf(stderr, "Unable to open \"%s\" for reading\n",
                    fileInfo->specIn);
            fileInfo->jobInvalid = true;
        }

    } else { //remaining index will be write index (SPEC_OUT_INDEX)
        readOrWrite = WRITE_END;
        if (!strcmp(fileInfo->specOut, "-")) {
            specIO = STANDARD_OUT;
        } else if (fileInfo->specOut[PIPE_SYMBOL_INDEX] == PIPE_SYMBOL) {
            allocate_pipe_ends(jobfiles, fileInfo->specOut, WRITE_END);
            isPipe = true;
            specIO = STANDARD_OUT;
 
        } else {
            specIO = open(fileInfo->specOut, O_WRONLY | O_CREAT | O_TRUNC,
                    S_IRWXU);
        }
        if (specIO == -1 && !isPipe) {
            fprintf(stderr, "Unable to open \"%s\" for writing\n",
                    fileInfo->specOut);
            fileInfo->jobInvalid = true;
        } 
    }

    if (specIO) {
        fileInfo->specIO[readOrWrite] = specIO;
    }
}

/*
 * Calls allocate_input_output to populate fileInfo argument, with jobfiles 
 * argument also passed into this function. Function allocates the fileInfo's
 * timeoutValue, in the case that the timeout is not an EMPTY_FIELD. 
 */
void input_output_allocation(JobfileParameters* fileInfo, Jobfiles* jobfiles) {
    //since SPEC_IN_INDEX is 1, and SPEC_OUT_INDEX is 2
    for (int specIndex = SPEC_IN_INDEX; specIndex <= SPEC_OUT_INDEX;
            specIndex++) {
        allocate_input_output(fileInfo, specIndex, jobfiles);
    }


    if (strcmp(fileInfo->timeout, EMPTY_FIELD)) {
        fileInfo->timeoutValue = atoi(fileInfo->timeout);
    }
}

/*
 * Reads each line of the givenJobfile and parses the information provided. 
 * If the fileLine contains a '#' at the beginning or the fileLine is an 
 * EMPTY_FIELD, then it is ignored. 
 * Calls sort_parameters() to populate fileInfo variable with the information
 * provided in the fileLine. If check_parameters() returns false, 
 * parsing_error() is called with the lineNumber and the fileName that has 
 * an invalid job specification. Otherwise, the fileInfo variable is allocated
 * input and output, and then added to jobfiles' fileParameters array.
 */
void parse_jobfiles(FILE* givenJobfile, char* jobfileName, 
        Jobfiles* jobfiles) {
    char* fileLine;
    int lineNumber = 0;
    while ((fileLine = read_line(givenJobfile))) {
        lineNumber++;
        if (fileLine[0] == '#' || !strcmp(fileLine, EMPTY_FIELD)) {
            continue;
        }

        JobfileParameters fileInfo = PARAMETER_SETUP;
        sort_parameters(fileLine, &fileInfo);

        if (!check_parameters(&fileInfo)) {
            parsing_error(lineNumber, jobfileName);
        }
        input_output_allocation(&fileInfo, jobfiles);
       
        jobfiles->numberOfParameters++;
        jobfiles->fileParameters = realloc(jobfiles->fileParameters,
                sizeof(JobfileParameters) * (jobfiles->numberOfParameters));
        jobfiles->fileParameters[jobfiles->numberOfParameters - 1] = fileInfo;

    }
    free(fileLine);
}

/*
 * Generates a pipe that has a read and write file descriptor associated with 
 * a pipe name. If the number of pipes is not 0, then the name of the given 
 * pipeEnd is checked to see if its designated pipe has alraedy been added. If
 * it has, the function returns, else a pipe with a pipeName specified by the 
 * pipeEnd is created and saved in jobfiles' fileDescriptors array.
 */
void add_pipe_descriptors(JobfilePipeEnds* pipeEnd, Jobfiles* jobfiles) {
    if (jobfiles->numberOfPipes == 0) {
        jobfiles->numberOfPipes++;
    } else {
        for (int pipeIndex = 0;
                pipeIndex < jobfiles->numberOfPipes;
                pipeIndex++) {
            char* addedPipe = jobfiles->fileDescriptors[pipeIndex].pipeName;
            if (!strcmp(pipeEnd->pipeName, addedPipe)) {
                return; 
                //don't continue process if pipe already given descriptors
            }
        }
        jobfiles->numberOfPipes++;
    }

    int numberOfPipes = jobfiles->numberOfPipes;     
    jobfiles->fileDescriptors = realloc(jobfiles->fileDescriptors,
            sizeof(JobfilePipeDescriptors) * numberOfPipes);

    jobfiles->fileDescriptors[numberOfPipes - 1].pipeName = pipeEnd->pipeName;
    int pipeDescriptors[PIPE_BUFFER];
    pipe(pipeDescriptors);
    
    jobfiles->fileDescriptors[numberOfPipes - 1].inputDescriptor =
            pipeDescriptors[READ_END];
    
    jobfiles->fileDescriptors[numberOfPipes - 1].outputDescriptor =
            pipeDescriptors[WRITE_END];
}

/*
 * Renders both the checkedPipe and the pipePair as invalid and prints an error
 * message stating the checkedPipeName for this pipe pair. Both pipes have 
 * printed variable set to true.
 */
void bad_pipe_pairs(JobfilePipeEnds* checkedPipe, JobfilePipeEnds* pipePair,
        char* checkedPipeName) {
    checkedPipe->validPipe = false; // reoccurrence
    pipePair->validPipe = false;
    pipePair->printed = true;
    checkedPipe->printed = true;
    fprintf(stderr, "Invalid pipe usage \"%s\"\n", checkedPipeName);
}

/*
 * Checks the validity of the pipes given in jobfiles array of filePipes. 
 * A pipe is valid if there is exactly one reference for each end of the pipe. 
 * If a pipe is deemed to be invalid, an error message indicating which pipe is
 * invalid is printed and the validPipe variable of the JobfilePipeEnd is set
 * to true. Error messages are printed once for each invalid pipe. If a pipe is
 * valid, add_pipe_descriptors() function is called to create the pipes 
 * corresponding to the checkedPipe's name. This updates the jobfiles array of
 * fileDescriptors with the relevant valid pipes. 
 */
void check_pipe_validity(Jobfiles* jobfiles) {
    for (int pipeEndIndex = 0; pipeEndIndex < jobfiles->numberOfPipeEnds;
            pipeEndIndex++) {
        JobfilePipeEnds* checkedPipe = &(jobfiles->filePipes[pipeEndIndex]);
        char* checkedPipeName = malloc(sizeof(char) * 
                strlen(checkedPipe->pipeName));
        strcpy(checkedPipeName, checkedPipe->pipeName);
        memmove(checkedPipeName, checkedPipeName + 1, strlen(checkedPipeName));
        for (int checkingIndex = 0; 
                checkingIndex < jobfiles->numberOfPipeEnds; checkingIndex++) {
            if (checkingIndex != pipeEndIndex) {
                JobfilePipeEnds* possiblePair = 
                        &(jobfiles->filePipes[checkingIndex]);
                if (!strcmp(possiblePair->pipeName, checkedPipe->pipeName)) {
                    if (possiblePair->pipeDirection != 
                            checkedPipe->pipeDirection &&
                            !checkedPipe->validPipe &&
                            !checkedPipe->printed) {
                        checkedPipe->validPipe = true;
                    } else if (checkedPipe->printed || possiblePair->printed) {
                        checkedPipe->printed = true;
                        possiblePair->printed = true;
                    } else if (checkedPipe->validPipe && 
                            !(checkedPipe->printed || possiblePair->printed)) {
                        // was originally valid, then find another 
                        bad_pipe_pairs(checkedPipe, possiblePair,
                                checkedPipeName);
                    } else if (checkedPipe->pipeDirection == 
                            possiblePair->pipeDirection &&
                            !(possiblePair->printed || checkedPipe->printed)) {
                        // same direction and same name
                        bad_pipe_pairs(checkedPipe, possiblePair, 
                                checkedPipeName);
                    }
                }
            }
        }
        if (!(checkedPipe->validPipe) && !(checkedPipe->printed)) {
            fprintf(stderr, "Invalid pipe usage \"%s\"\n", checkedPipeName);
        } else if (checkedPipe->validPipe) {
            add_pipe_descriptors(checkedPipe, jobfiles);
        }
        free(checkedPipeName);
    }
}

/*
 * Function invalidates a pipe and returns whether an update of the check in 
 * pipes_cascading_invalidate() is required. jobs_cascading_invalidate() also 
 * calls this function, but ignores return value. 
 * In the case the pipeEnd was initially valid and the name of the pipEnd 
 * is the same as the given pipeEndName to invalidate, pipeEnd is invalidated 
 * and update returns true, else update returns false. 
 */
bool invalidate_pipe_end(char* pipeEndName, Jobfiles* jobfiles) {
    bool update = false;
    for (int pipeEndIndex = 0; pipeEndIndex < jobfiles->numberOfPipeEnds;
            pipeEndIndex++) {
        JobfilePipeEnds* pipeEnd = &(jobfiles->filePipes[pipeEndIndex]);
        if (pipeEnd->validPipe && !strcmp(pipeEndName, pipeEnd->pipeName)) {
            pipeEnd->validPipe = false;
            update = true;
        }
    }
    return update;
}

/*
 * Function provides cascading invalidity of jobs due to an invalid job due to 
 * file opening is linked with a pipe end. 
 * From the jobfiles' fileParameters array, checks if an invalid job is 
 * has its specIn or specOut as a pipe, and invalidates that pipeEnd by calling
 * invalidate_pipe_end(). Return value is ignored as no re-check is required.
 */
void jobs_cascading_invalidate(Jobfiles* jobfiles) {
// can ignore return value of update since no need to re-check
    for (int jobIndex = 0; jobIndex < jobfiles->numberOfParameters; 
            jobIndex++) {
        JobfileParameters fileInfo = jobfiles->fileParameters[jobIndex];
        if (fileInfo.jobInvalid) {
            if (fileInfo.specIn[0] == PIPE_SYMBOL) {
               invalidate_pipe_end(fileInfo.specIn, jobfiles);
            } else if (fileInfo.specOut[0] == PIPE_SYMBOL) {
               invalidate_pipe_end(fileInfo.specOut, jobfiles);
            }
        }
    }
}

/*
 * Function provides cascading invalidity of pipe ends. Checks each job in 
 * jobfiles' fileParameters array to see if an invalid pipe end is linked to 
 * another pipe end. If it is, the other pipe end is set to be invalid using
 * invalidate_pipe_end() function. 
 */
void pipes_cascading_invalidate(Jobfiles* jobfiles) {
    for (int pipeEndIndex = 0; pipeEndIndex < jobfiles->numberOfPipeEnds;
            pipeEndIndex++) {
        JobfilePipeEnds pipeEnd = jobfiles->filePipes[pipeEndIndex];
        if (!pipeEnd.validPipe) {
            bool update = false;
            for (int jobIndex = 0; jobIndex < jobfiles->numberOfParameters;
                    jobIndex++) {
                JobfileParameters fileInfo = 
                        jobfiles->fileParameters[jobIndex];

                if (!strcmp(pipeEnd.pipeName, fileInfo.specIn) && 
                        fileInfo.specOut[0] == PIPE_SYMBOL) {
                    update = invalidate_pipe_end(fileInfo.specOut, jobfiles);
                    
                } else if (!strcmp(pipeEnd.pipeName, fileInfo.specOut) &&
                        fileInfo.specIn[0] == PIPE_SYMBOL) {
                    update = invalidate_pipe_end(fileInfo.specIn, jobfiles);
                }
            }
            if (update) {
                // indicates there could be more invalid pipes to check,
                // so check again from the start
                pipeEndIndex = 0;
            }
        }
    }
}

/*
 * Updates validity of jobs specified in the jobfiles' fileParameters array. 
 * If a job is previously not rendered invalid due to input/output file 
 * opening, job will be check if it uses an invalid pipe end. If it does, job
 * is set to invalid, else numValidJobs is incremented. In the case no jobs are
 * valid, error message is printed and program exits with status 4. 
 * 
 */
void update_invalid_jobs(Jobfiles* jobfiles) {
    int numValidJobs = 0;
    for (int jobIndex = 0; jobIndex < jobfiles->numberOfParameters;
            jobIndex++) {
        JobfileParameters* fileInfo = &(jobfiles->fileParameters[jobIndex]);
        if (!fileInfo->jobInvalid) {
            // checking if an invalid pipe renders a valid job invalid.
            for (int pipeEndNumber = 0;
                    pipeEndNumber < jobfiles->numberOfPipeEnds;
                    pipeEndNumber++) {
                JobfilePipeEnds checkPipe = jobfiles->filePipes[pipeEndNumber];
                if ((!strcmp(fileInfo->specIn, checkPipe.pipeName) ||
                        !strcmp(fileInfo->specOut, checkPipe.pipeName)) &&
                        !checkPipe.validPipe) {
                    fileInfo->jobInvalid = true;
                }
               
            }

            if (!fileInfo->jobInvalid) {
                numValidJobs++;
            }
        }
    }
    if (numValidJobs == 0) {
        fprintf(stderr, "jobrunner: no runnable jobs\n");
        exit(4);
    }
}

/*
 * Redirects the standard in and standard out of the process to a pipe end for 
 * a given filePipeName. The jobfiles fileDescriptors array holds file 
 * descriptors corresponding to the given filePipeName, of which will be used
 * in a dup2() call for redirection. In the case the pipeEnd is READ_END, then
 * the standard in of the process is changed to be the inputDescriptor of the 
 * pipe (reading end), else if the pipeEnd is WRITE_END, the standard out of 
 * the process is redirected to the outputDescriptor of the pipe (writing end).
 */
void open_pipe_end(char* filePipeName, Jobfiles* jobfiles, int pipeEnd) {
    
    for (int pipeIndex = 0;
            pipeIndex < jobfiles->numberOfPipes;
            pipeIndex++) {
        char* comparedName = jobfiles->fileDescriptors[pipeIndex].pipeName;
        if (strstr(filePipeName, comparedName)) {
            int newInputOutput;
            if (pipeEnd == READ_END) {
                newInputOutput = 
                        jobfiles->fileDescriptors[pipeIndex].inputDescriptor; 
                dup2(newInputOutput, READ_END); 
                close(newInputOutput);

            } else if (pipeEnd == WRITE_END) {
                newInputOutput = 
                        jobfiles->fileDescriptors[pipeIndex].outputDescriptor;

                dup2(newInputOutput, WRITE_END); 
                close(newInputOutput);
            }
            return;            
        }
    }
}

/*
 * Close all file descriptors for pipe ends saved in jobfiles fileDescriptors
 * array. 
 */
void close_file_descriptors(Jobfiles* jobfiles) {
    for (int pipeIndex = 0; pipeIndex < jobfiles->numberOfPipes; pipeIndex++) {
        close(jobfiles->fileDescriptors[pipeIndex].inputDescriptor);
        close(jobfiles->fileDescriptors[pipeIndex].outputDescriptor);
    }
}

/*
 * Executes a job with redirected standard in and standard out as specified in 
 * JobfileParameters argument.
 * Standard error from the execution of this job is suppressed. Standard in
 * and out can be redirected from stdin and stdout to files specified in the 
 * specIO variable of the job argument or to an input or output end of a pipe. 
 * For pipe redirecetion, open_pipe_end function is called with the specified 
 * direction, the given name from job and jobfiles for its fileDescriptor 
 * array. Once everything has been redirected, pipes in are closed using 
 * close_file_descriptors. If the given program cannot be executed, 
 * the process exits with an exit status of 255, else it exits normally.
 */
void child_execute_job(JobfileParameters job, Jobfiles* jobfiles) {
    int suppress = open("/dev/null", O_WRONLY);
    dup2(suppress, STANDARD_ERROR);
    close(suppress);
    
    if (job.specIO[READ_END] != STANDARD_IN) {
        dup2(job.specIO[READ_END], STANDARD_IN);
        close(job.specIO[READ_END]);
    } else if (job.specIn[PIPE_SYMBOL_INDEX] == PIPE_SYMBOL) {
        open_pipe_end(job.specIn, jobfiles, READ_END);
    }

    if (job.specIO[WRITE_END] != STANDARD_OUT) {
        dup2(job.specIO[WRITE_END], STANDARD_OUT);
        close(job.specIO[WRITE_END]);

    } else if (job.specOut[PIPE_SYMBOL_INDEX] == PIPE_SYMBOL) {
        open_pipe_end(job.specOut, jobfiles, WRITE_END);
    }
    //since already redirected with dup2, close all descriptors
    close_file_descriptors(jobfiles);
    
    if (execvp(job.programName, job.givenArguments) == -1) {
        exit(255);
    }
}

/*
 * Function checks up on a total of numberOfJobsRun child processes saved in 
 * runJobs and returns remainingJobsAfterCheck. remainingJobsAfterCheck is 
 * initially set to the value of numberOfJobsRemaining.
 * Each child process is checked in the loop. Once a child has 
 * terminated, jobrunner prints the exit status of the job, or if terminated
 * by a signal, the signal number is specified. Child's PID saved in runJobs is
 * set to 0, indicating job complete. 
 * If any child sends a SIGHUP signal to the jobrunner, the global variable 
 * terminateChildren is set and jobrunner sends SIGKILL to all the remaining 
 * children. 
 * In the case that the timeElapsed is equal to the timeoutValue of the job and
 * the child is still alive, child is sent SIGABRT signal (timeoutValue must be
 * greater than 0). The job in runJobs is given a timeout of true. In the case
 * the job blocks the SIGABRT, jobrunner sends SIGKILL.
 */
int check_on_children(RunnableFileInfo* runJobs, 
        int numberOfJobsRemaining, int numberOfJobsRun, int timeElapsed) {
    int status;
    int remainingJobsAfterCheck = numberOfJobsRemaining;
    for (int runJobIndex = 0; runJobIndex < numberOfJobsRun;
            runJobIndex++) {
        int childPID = runJobs[runJobIndex].childPID;
        int timeoutValue = runJobs[runJobIndex].timeoutValue; 
        if (terminateChildren) {
            kill(childPID, SIGKILL);
        } else if (timeoutValue == timeElapsed && timeoutValue != 0 &&
                childPID != 0) {
            kill(childPID, SIGABRT);
            runJobs[runJobIndex].timeout = true;
        }
            
        if (!waitpid(childPID, &status, WNOHANG)) {
            if (timeoutValue < timeElapsed && 
                    runJobs[runJobIndex].timeout) {
                kill(childPID, SIGKILL);
            }
            continue;
        }
        
        if (childPID != 0) {
            if (WIFEXITED(status)) {
                fprintf(stderr, "Job %d exited with status %d\n", 
                        runJobs[runJobIndex].jobfileNumber,
                        WEXITSTATUS(status));
                //set PID of child to 0 to indicate job finished
                runJobs[runJobIndex].childPID = 0;
                remainingJobsAfterCheck--;
            } else if (WIFSIGNALED(status)) {
                fprintf(stderr, "Job %d terminated with signal %d\n", 
                        runJobs[runJobIndex].jobfileNumber,
                        WTERMSIG(status));
                runJobs[runJobIndex].childPID = 0;
                remainingJobsAfterCheck--;
            }
        }
        fflush(stderr);
    }
    return remainingJobsAfterCheck;
}

/*
 * Runs valid jobs specified in jobfiles array of fileParameters. Function 
 * gives each job a jobfile number, but only runs valid jobs. fork() is called,
 * with the child executing the job using child_execute_job() function. 
 * Every second, the child processes are checked using check_on_children(). 
 * When the numberOfJobsRemaining is no longer greater than 0, loop breaks.
 */
void run_jobs(Jobfiles* jobfiles) {
    RunnableFileInfo* runJobs = malloc(sizeof(RunnableFileInfo));
    int numberOfJobsRun = 0;

    for (int jobfileNumber = 1; 
            jobfileNumber <= jobfiles->numberOfParameters;
            jobfileNumber++) {
        if (!((jobfiles->fileParameters[jobfileNumber - 1]).jobInvalid)) {
            numberOfJobsRun++;
            runJobs = realloc(runJobs, 
                    sizeof(RunnableFileInfo) * numberOfJobsRun);
            runJobs[numberOfJobsRun - 1].jobfileNumber = jobfileNumber;
            runJobs[numberOfJobsRun - 1].timeout = false; 
            
            JobfileParameters job = 
                    (jobfiles->fileParameters[jobfileNumber - 1]);
            runJobs[numberOfJobsRun - 1].timeoutValue = job.timeoutValue;
            
            pid_t pid;
            pid = fork();
            if (!pid) {
                child_execute_job(job, jobfiles);
            } else {
                runJobs[numberOfJobsRun - 1].childPID = pid;
            }
        }
    }

    //closing pipes in parents, allows the child to terminate and not wait
    close_file_descriptors(jobfiles);
    int timeElapsed = 0;
    int numberOfJobsRemaining = numberOfJobsRun;
    while (1) {
        //separateFunction???
        if (numberOfJobsRemaining == 0) {
            break;
        }
        sleep(1);
        timeElapsed++;
        numberOfJobsRemaining = check_on_children(runJobs,
                numberOfJobsRemaining, numberOfJobsRun, timeElapsed);
        
    }
    free(runJobs);
}

/*
 * If verbose is true in jobfiles, prints all the runnable jobs in the 
 * following format:
 *      jobNum:command:stdin:stdout:timeout[:arg1[:arg2...]]
 * Unrunnable jobs are still given a jobNum, however are not printed out. 
 */
void print_verbose(Jobfiles* jobfiles) {
    for (int jobfileNumber = 1;
            jobfileNumber <= jobfiles->numberOfParameters;
            jobfileNumber++) {
        JobfileParameters job = jobfiles->fileParameters[jobfileNumber - 1];
        if (!job.jobInvalid) {
            fprintf(stderr, "%d:%s:%s:%s:%d", jobfileNumber,
                    job.programName, job.specIn, job.specOut,
                    job.timeoutValue);
            if (job.numberOfArguments > 1) {
                for (int argumentNumber = 1;
                        argumentNumber < job.numberOfArguments;
                        argumentNumber++) {
                    fprintf(stderr, ":%s", job.givenArguments[argumentNumber]);
                }
            }
            fprintf(stderr, "\n");

        }
    }    
}

int main(int argc, char* argv[]) {
    Jobfiles jobfiles = JOBFILE_SETUP;
    
    struct sigaction signalReceiver;
    memset(&signalReceiver, 0, sizeof(signalReceiver));
    signalReceiver.sa_handler = sighup_received;
    signalReceiver.sa_flags = SA_RESTART;
    sigaction(SIGHUP, &signalReceiver, 0);

    for (int commandLineIndex = 1; commandLineIndex < argc; 
            commandLineIndex++) {
        check_verbose(&jobfiles, argv[commandLineIndex], commandLineIndex);
        if (jobfiles.verbose && commandLineIndex == 1) {
            continue;
        }
        filter_input(&jobfiles, argv[commandLineIndex]);
    }

    if (jobfiles.numberOfJobfiles == 0) {
        usage_error();
    }
    for (int jobfileIndex = 0; jobfileIndex < jobfiles.numberOfJobfiles; 
            jobfileIndex++) {
        parse_jobfiles(jobfiles.listOfJobfiles[jobfileIndex],
                jobfiles.jobfileNames[jobfileIndex],
                &jobfiles);
    }
    
    check_pipe_validity(&jobfiles);
    jobs_cascading_invalidate(&jobfiles);
    pipes_cascading_invalidate(&jobfiles);

    update_invalid_jobs(&jobfiles);
    if (jobfiles.verbose) {
        print_verbose(&jobfiles);
    }

    run_jobs(&jobfiles);

    return 0;
}
 
