#ifndef _INTCLIENT_H
#define _INTCLIENT_H

// Libraries
#include "functions.h"
#include <sys/types.h>
#include <stdbool.h>
#include <stdio.h>

// Macros
#define VERBOSE_INDEX 1
#define PARTIAL_RESULT_SPLITTER '\n'

// Function Declarations
void usage_error(void);
bool check_verbose(char* commandLineInput);
void check_command_line(int* jobfile, char** serviceName, char* input);
void socket_connect_fail(char* serviceName, struct addrinfo* addressInfo);
int connect_to_server(char* serviceName);
void print_result(char* body, JobfileInformation parameters, bool verbose);
void communication_error(void);
bool send_requests(JobfileInformation parameters, int lineNumber, int socket,
        RequestType type, bool verbose);
void parse_jobfiles(FILE* givenJobfile, int socket, bool verbose);

#endif
