#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <sys/types.h>
#include <csse2310a4.h>
#include <ctype.h>
#include <pthread.h>
#include <tinyexpr.h>
#include <semaphore.h>
#include "functions.h"
#include "intserver.h"

/*
 * Prints usage error message and exits with status 1.
 */
void usage_error(void) {
    fprintf(stderr, "Usage: intserver portnum [maxthreads]\n");
    exit(1);
}

/* 
 * Prints error unable to listen error message and exits with status 3. Frees 
 * given addressInformation struct.
 */
void error_open_to_listen(struct addrinfo* addressInformation) {
    freeaddrinfo(addressInformation);
    fprintf(stderr, "intserver: unable to open socket for listening\n");
    exit(3);
}

/*
 * Connects to port portNumber on localhost and binds to the socket. Prints 
 * out the portNumber once connected.
 */
int open_server(char* portNumber) {
    struct addrinfo* addressInformation = 0;
    struct addrinfo hints;
    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    if (getaddrinfo("localhost", portNumber, &hints, &addressInformation)) {
        error_open_to_listen(addressInformation);
    }

    int server = socket(AF_INET, SOCK_STREAM, 0);
    if (bind(server, (struct sockaddr*) addressInformation->ai_addr,
            sizeof(struct sockaddr))) {
        error_open_to_listen(addressInformation);

    }

    struct sockaddr_in address;
    memset(&address, 0, sizeof(struct sockaddr_in));
    socklen_t length = sizeof(struct sockaddr_in);

    if (getsockname(server, (struct sockaddr*) &address, &length)) {
        error_open_to_listen(addressInformation);
    }

    fprintf(stderr, "%u\n", ntohs(address.sin_port));
    fflush(stderr);
    return server;
}

/*
 * Checks if given portNumber is valid. Valid ports are strictly numerical and 
 * are positive integers less than 65535. Usage_error() called in case of 
 * invalid portNumber.
 */
void check_valid_port(char* portNumber) {
    for (int characterIndex = 0; characterIndex < strlen(portNumber); 
            characterIndex++) {
        if (!isdigit(portNumber[characterIndex])) {
            usage_error();
        }
    }
    if (atoi(portNumber) < 0 || atoi(portNumber) > 65535) {
        usage_error();
    }
}

/*
 * Validates givenExpression and sends back a response to client through 
 * clientDescriptor if the request is VALIDATE. Returns true if givenExpression
 * valid, else returns false and if request VALIDATE, sends bad request to
 * client.
 *
 */
bool validate_expression(ClientInformation* client, char* givenExpression, 
        RequestType request) {
    double x;
    te_variable variables[] = {{"x", &x}};
    int error;
    bool valid;
    char* response;

    te_expr* checkedExpression = te_compile(givenExpression, variables, 1, 
            &error);
    if (checkedExpression) {
        response = construct_HTTP_response(200, "OK", NULL, NULL);
        valid = true;
    } else {
        response = construct_HTTP_response(400, "Bad Request", NULL, NULL);
        valid = false;
    }
    if (request == VALIDATE) {
        // bad request for integration if somehow an invalid expression passes
        send(client->clientDescriptor, response, strlen(response), 0);
    }

    te_free(checkedExpression);
    return valid;
}

/*
 * Sends a bad request to client through clientDescriptor.
 */
void send_bad_request(int clientDescriptor) {
    char* badRequest = construct_HTTP_response(400, "Bad Request", NULL, NULL);
    send(clientDescriptor, badRequest, strlen(badRequest), 0);
}

/*
 * Computes the integral of given section specified in ComputationInformation
 * struct computation for an individual thread. On exit, returns the 
 * final result of the threads integration as a void*. 
 */ 
void* computation_thread(void* computation) {
    ComputationInformation values = *(ComputationInformation*) computation;
    double x, y1, y2, threadResult = 0;

    te_variable variables[] = {{"x", &x}};
    int error, numberOfSegments = 0;

    te_expr* expression = te_compile(values.functionName, variables, 1, 
            &error);

    x = values.lowerBound;
    y1 = te_eval(expression);
    while (numberOfSegments < values.segmentCount) {
        numberOfSegments++;
        x += values.segmentSize;
        y2 = te_eval(expression);
        double area = values.segmentSize * 0.5 * (y1 + y2);
        threadResult += area;
        y1 = y2;
    }

    if (values.capped) {
        ComputationInformation* storedComputation = 
                (ComputationInformation*) computation;
        sem_post(storedComputation->maxThreadKey);
    }

    double* finalResult = malloc(sizeof(double));
    *finalResult = threadResult;
    te_free(expression);

    pthread_exit((void*) finalResult);
}

/*
 * From given headers array, checks for verbose header. If verbose header 
 * present and value is yes, returns true, else returns false.
 */ 
bool check_verbose_headers(HttpHeader** headers) {
    int headerIndex = 0;
    HttpHeader* checkedHeader;
    bool verbose = false;
    while ((checkedHeader = headers[headerIndex])) {
        if (!strcmp(checkedHeader->name, "X-Verbose") && 
                !strcmp(checkedHeader->value, "yes")) {
            verbose = true;
            break; // ignoring other headers
        }
        headerIndex++;
    }
    return verbose;
}

/* 
 * Allocates values to segmentsPerThread, threadWidth and segmentSize pointers
 * with specifications given in job.
 */
void setup_computation_parameters(double* segmentsPerThread, 
        double* threadWidth, double* segmentSize, JobfileInformation job) {
    *(threadWidth) = 
            (double) (job.upperLimit - job.lowerLimit) / job.numberOfThreads;

    *(segmentsPerThread) = job.numberOfSegments / job.numberOfThreads;

    *(segmentSize) = 
            (job.upperLimit - job.lowerLimit) / (double) job.numberOfSegments;
}

/*
 * Runs all computation threads, with thread id given in threadId array. 
 * Returns a ComputationInformation array holding information given from job
 * struct and client struct for the individual computation threads.
 * SIGHUP statistics handled by client struct.
 */
ComputationInformation* run_threads(pthread_t* threadId, 
        JobfileInformation job, ClientInformation* client) {
    double threadWidth, segmentsPerThread, segmentSize;
    setup_computation_parameters(&segmentsPerThread, &threadWidth, 
            &segmentSize, job);
    ComputationInformation* threadData =
            malloc(sizeof(ComputationInformation));

    for (int threadNumber = 1; threadNumber <= job.numberOfThreads; 
            threadNumber++) {
        ComputationInformation* computation =
                malloc(sizeof(ComputationInformation));
        computation->functionName = job.function;
        computation->lowerBound =
                job.lowerLimit + (threadNumber - 1) * threadWidth;
        computation->upperBound = 
                job.lowerLimit + threadNumber * threadWidth;
        computation->segmentCount = segmentsPerThread;
        computation->segmentSize = segmentSize;

        if (client->threadCap) {
            computation->maxThreadKey = client->maxThreadKey;
        }
        computation->capped = client->threadCap;
        threadData = realloc(threadData, 
                sizeof(ComputationInformation) * threadNumber);
        threadData[threadNumber - 1] = *computation;

        if (client->threadCap) {
            sem_wait(client->maxThreadKey);
        }
        pthread_create(&threadId[threadNumber - 1], NULL, computation_thread, 
                (void*) computation);
        sem_wait(client->sighupKey);
        client->sighupDetails->totalComputationThreads++;
        sem_post(client->sighupKey);
    }
    return threadData;
}

/*
 * Completes the integration request specified in job and result is sent back
 * to client through clientDescriptor in client struct. If given headers array
 * is checked and indicates verbose is true, partial results are appended to
 * the response.
 */
void complete_job(ClientInformation* client, JobfileInformation job, 
        HttpHeader** headers) {
    bool verbose = check_verbose_headers(headers);
    double integrationResult;
    pthread_t threadId[job.numberOfThreads];
    ComputationInformation* threadData = run_threads(threadId, job, client);
    char* body = malloc(STRING_SIZE);
    bool added = false;
    
    for (int threadNumber = 1; threadNumber <= job.numberOfThreads; 
            threadNumber++) {
        void* threadResult;
        pthread_join(threadId[threadNumber - 1], &threadResult);
        ComputationInformation threadResults = threadData[threadNumber - 1]; 

        if (verbose) {
            char* partialResult = malloc(STRING_SIZE);
            sprintf(partialResult, "thread %d:%lf->%lf:%lf\n", threadNumber,
                    threadResults.lowerBound, threadResults.upperBound, 
                    *(double*) threadResult);

            if (added) {
                body = realloc(body, strlen(body) + strlen(partialResult) + 2);
                strcat(body, partialResult);
            } else {
                strcpy(body, partialResult);
                added = true;
            }
        }
        integrationResult += *(double*) threadResult;
    }

    char* finalResult = malloc(STRING_SIZE);
    sprintf(finalResult, "%lf\n", integrationResult);
    if (added) {
        body = realloc(body, strlen(body) + strlen(finalResult) + 2);
        strcat(body, finalResult);
    } else {
        strcpy(body, finalResult);
    }

    char* response = construct_HTTP_response(200, "OK", NULL, body);
    if (send(client->clientDescriptor, response, strlen(response), 0) == -1) {
        close(client->clientDescriptor);
    } else {
        sem_wait(client->sighupKey);
        client->sighupDetails->completedJobsCount++;
        sem_post(client->sighupKey);
    }
}

/*
 * Checks validity of given request and handles request given in address. 
 * Argument client used for SIGHUP statistics. 
 * Both headers and client are passed into other function calls. If in any 
 * case the request is invalid, client is sent a bad request through 
 * clientDescriptor in client struct.
 */
void parse_request_information(ClientInformation* client, char* address, 
        HttpHeader** headers) {
    char** segments = split_by_char(address, ADDRESS_SPLITTER, 3);
    // format {"", "request", "request info"}
    RequestType request;
    if (!strcmp(segments[REQUEST_INDEX], "validate")) {
        request = VALIDATE;
        // ignore return of validate_expression
        validate_expression(client, segments[CHECKED_INDEX], request);

        sem_wait(client->sighupKey);
        client->sighupDetails->expressionCheckCount++;
        sem_post(client->sighupKey);

    } else if (!strcmp(segments[REQUEST_INDEX], "integrate")) {
        request = INTEGRATE;
        JobfileInformation job = 
                get_file_information(segments[CHECKED_INDEX], 0);

        if (!validate_expression(client, job.function, request) || 
                job.syntaxError || !check_file_information(job, 0)) {
            send_bad_request(client->clientDescriptor);

            sem_wait(client->sighupKey);
            client->sighupDetails->badJobsCount++;
            sem_post(client->sighupKey);
        } else {
            complete_job(client, job, headers);
        }
    } else { // request is something other than validate and integrate
        send_bad_request(client->clientDescriptor);
    }
}

/*
 * Thread deals with client specified by givenClient. Is detached and therefore
 * cleans itself up. 
 */
void* client_thread(void* givenClient) {

    ClientInformation client = *(ClientInformation*) givenClient;
    sem_wait(client.sighupKey);
    client.sighupDetails->currentNumberClients++;
    sem_post(client.sighupKey);
    
    char* checkedRequest = malloc(STRING_SIZE);
    while (recv(client.clientDescriptor, checkedRequest, STRING_SIZE - 1,
                MSG_PEEK) > 0) {
        ParsingEnd type = SERVER;
        char* method;
        char* address;
        HttpHeader** headers;
        char* body;
        int requestStatus = get_response_request(client.clientDescriptor, NULL,
                &method, &address, &headers, &body, type);
        
        if (requestStatus == -1) {
            close(client.clientDescriptor);
            continue;
        } else if (strcmp(method, "GET")) {
            send_bad_request(client.clientDescriptor);
            continue;
        }
        parse_request_information(&client, address, headers);
    }
    if (client.clientDescriptor) {
        close(client.clientDescriptor);
    }

    sem_wait(client.sighupKey);
    client.sighupDetails->currentNumberClients--;
    sem_post(client.sighupKey);

    pthread_exit(NULL);
}

/*
 * Thread waits for incoming signal using signalSet saved in sighupDetails. 
 * Thread is alive for as long as server is alive.
 */
void* sighup_thread(void* sighupDetails) {
    sigset_t signalSet;
    sigemptyset(&signalSet);
    sigaddset(&signalSet, SIGHUP);

    SighupInformation* stats = (SighupInformation*) sighupDetails;
    int signalResponse, signalReceived;
    while (true) { // while server alive always check for signal
        signalResponse = sigwait(&signalSet, &signalReceived);
        if (signalResponse == 0 && signalReceived == SIGHUP) {
            sem_wait(stats->sighupKey);

            fprintf(stderr, "Connected clients:%d\nExpressions checked:%d\n"
                    "Completed jobs:%d\nBad jobs:%d\nTotal threads:%d\n",
                    stats->currentNumberClients, stats->expressionCheckCount,
                    stats->completedJobsCount,stats->badJobsCount,
                    stats->totalComputationThreads);
            
            sem_post(stats->sighupKey);
            fflush(stderr);
            pthread_sigmask(SIG_BLOCK, &signalSet, stats->signalSet);
        }
    }
}

/*
 * Initialises required signalSet for sighupDetails and runs sighup_thread().
 */
void create_sighup_thread(SighupInformation* sighupDetails) {
    sigset_t signalSet;
    sigemptyset(&signalSet);
    sigaddset(&signalSet, SIGHUP);

    pthread_sigmask(SIG_BLOCK, &signalSet, NULL);
    sighupDetails->signalSet = &signalSet;

    pthread_t sighupThread;
    pthread_create(&sighupThread, NULL, sighup_thread, (void*) sighupDetails);
    pthread_detach(sighupThread);
}

/*
 * Listens and accepts clients on given socket descriptor server, opening up 
 * an individual client thread for each.
 * If maxThreads is given as a positive integer, thread limiting is setup and 
 * required limiting information is provided to client and sighupDetails.
 */
void server_listen(int server, int maxThreads) {
    SighupInformation sighupDetails = {0, 0, 0, 0, 0, NULL};
    sem_t sighupLock, maxThreadLock;
    sem_init(&sighupLock, 0, 1);
    bool threadCap;

    if (maxThreads) {
        threadCap = true;
        sem_init(&maxThreadLock, 0, maxThreads);
    } else {
        threadCap = false;
    }

    listen(server, 0);

    sighupDetails.sighupKey = &sighupLock;
    create_sighup_thread(&sighupDetails);

    while (true) {
        struct sockaddr_in clientAddress;
        socklen_t clientAddressSize;
        ClientInformation* client = malloc(sizeof(ClientInformation));
        client->clientDescriptor = accept(server, 
                (struct sockaddr*) &clientAddress, &clientAddressSize);
        client->sighupDetails = &sighupDetails;
        client->sighupKey = &sighupLock;
        if (threadCap) {
            client->maxThreadKey = &maxThreadLock;
        }
        client->threadCap = threadCap;
        pthread_t threadId;
        pthread_create(&threadId, NULL, client_thread, (void*) client);
        pthread_detach(threadId);
     }
}

int main(int argc, char* argv[]) {
    char* portNumber;
    int maxThreads = 0; // maxThreads will change from 0 if valid number given
    int server;
    
    if (argc > 3 || argc < 2) {
        usage_error();
    }

    for (int commandLineIndex = 1; commandLineIndex < argc; 
            commandLineIndex++) {
        if (commandLineIndex == PORT_INDEX) {
            portNumber = argv[commandLineIndex];
            // need to check if this is a string other than digits, since atoi
            // returns 0 in this case
            check_valid_port(portNumber);
        } else {
            maxThreads = atoi(argv[commandLineIndex]);
            if (maxThreads < 1) {
                usage_error();
            }
        }
    }
    server = open_server(portNumber);
    server_listen(server, maxThreads);
}


