#ifndef _INTSERVER_H
#define _INTSERVER_H

// Libraries

#include <netdb.h>
#include <semaphore.h>
#include <signal.h>
#include <csse2310a4.h>
#include <pthread.h>
#include <stdbool.h>
#include "functions.h"

// Macros
#define PORT_INDEX 1
#define REQUEST_INDEX 1

// Data Structures

/* Parameters for an individual computation thread. */
typedef struct {
    int segmentCount;
    double segmentSize;
    double lowerBound;
    double upperBound;
    char* functionName;
    bool capped;
    sem_t* maxThreadKey;
} ComputationInformation;

/* Server statistics. */
typedef struct {
    int totalComputationThreads;
    int completedJobsCount;
    int badJobsCount;
    int currentNumberClients;
    int expressionCheckCount;
    sigset_t* signalSet;
    sem_t* sighupKey;
} SighupInformation;

/* Information about an individual client. */
typedef struct {
    SighupInformation* sighupDetails;
    int clientDescriptor;
    int clientThreads;
    bool threadCap;
    sem_t* maxThreadKey;
    sem_t* sighupKey;
} ClientInformation;

// Function Declarations
void usage_error(void);
void error_open_to_listen(struct addrinfo* addressInformation);
int open_server(char* portNumber);
void check_valid_port(char* portNumber);
bool validate_expression(ClientInformation* client, char* givenExpression, 
        RequestType request);
void send_bad_request(int clientDescriptor);
void* computation_thread(void* computation);
bool check_verbose_headers(HttpHeader** headers);
void setup_computation_parameters(double* segmentsPerThread, 
        double* threadWidth, double* segmentSize, JobfileInformation job);
ComputationInformation* run_threads(pthread_t* threadId, 
        JobfileInformation job, ClientInformation* client);
void complete_job(ClientInformation* client, JobfileInformation job, 
        HttpHeader** headers);
void parse_request_information(ClientInformation* client, char* address, 
        HttpHeader** headers);
void* client_thread(void* givenClient);
void* sighup_thread(void* sighupDetails);
void create_sighup_thread(SighupInformation* sighupDetails);
void server_listen(int server, int maxThreads);
#endif

